// Client-side JavaScript (hospital.js)
let availableDoctors = [];

// Fetch available doctors on page load
async function fetchAvailableDoctors() {
    try {
        const response = await fetch("/api/hospital/doctors");
        const data = await response.json();
        availableDoctors = data.doctors.map(doc => doc.name); // only store names
    } catch (error) {
        console.error("Error fetching doctors:", error);
    }
}

async function fetchPendingRequests() {
    try {
        const response = await fetch("/api/patient/requests");
        const data = await response.json();
        const requestList = document.getElementById("pendingRequests");
        requestList.innerHTML = "";
        
        if (data.requests.length === 0) {
            requestList.innerHTML = "<p>No pending appointments</p>";
            return;
        }
        
        // Filter to only show unassigned or incomplete appointments
        const pendingRequests = data.requests.filter(req => 
            !req.assignedDoctor || !req.completed
        );
        
        if (pendingRequests.length === 0) {
            requestList.innerHTML = "<p>No pending appointments</p>";
            return;
        }
        
        pendingRequests.forEach(request => {
            const appointmentDiv = document.createElement("div");
            appointmentDiv.className = "appointment";
            if (request.emergency) {
                appointmentDiv.classList.add("emergency");
            }
            
            const emergency = request.emergency ? "⚠️ EMERGENCY" : "";
            const status = request.assignedDoctor ? 
                `<p><strong>Assigned to:</strong> ${request.assignedDoctor}</p>` : 
                "<p><strong>Status:</strong> Unassigned</p>";
                
            appointmentDiv.innerHTML = `
                <h3>${request.name} (${request.age}) ${emergency}</h3>
                <p>Department: ${request.department}</p>
                <p>Appointment Time: ${new Date(request.appointmentTime).toLocaleString()}</p>
                ${status}
            `;
            
            // Only show assignment options if not already assigned
            if (!request.assignedDoctor) {
                const doctorSelect = document.createElement("select");
                doctorSelect.innerHTML = `<option value="">Select Doctor</option>`;
                availableDoctors.forEach(doctor => {
                    const option = document.createElement("option");
                    option.value = doctor;
                    option.textContent = doctor;
                    doctorSelect.appendChild(option);
                });
                
                const assignButton = document.createElement("button");
                assignButton.textContent = "Assign";
                assignButton.onclick = async function() {
                    const selectedDoctor = doctorSelect.value;
                    if (!selectedDoctor) return alert("Please select a doctor");
                    
                    try {
                        const response = await fetch("/api/hospital/assign", {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({ requestId: request.id, doctorName: selectedDoctor })
                        });
                        const result = await response.json();
                        alert(result.message);
                        fetchPendingRequests();
                    } catch (error) {
                        console.error("Error assigning doctor:", error);
                        alert("Failed to assign doctor");
                    }
                };
                
                appointmentDiv.appendChild(doctorSelect);
                appointmentDiv.appendChild(assignButton);
            }
            
            requestList.appendChild(appointmentDiv);
        });
    } catch (error) {
        console.error("Error fetching requests:", error);
        document.getElementById("pendingRequests").innerHTML = 
            "<p>Error loading appointments. Please try again later.</p>";
    }
}

document.addEventListener("DOMContentLoaded", function() {
    fetchAvailableDoctors().then(() => fetchPendingRequests());
});

// Refresh data every 30 seconds
setInterval(fetchPendingRequests, 30000);