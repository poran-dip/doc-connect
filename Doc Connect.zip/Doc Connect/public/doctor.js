// Client-side JavaScript (doctor.js)
let doctorName = ""; // We'll set this when the page loads

// Initialize doctor selection
document.addEventListener("DOMContentLoaded", function() {
    promptForDoctorName();
    
    // Set up status change event listener
    document.getElementById("doctorStatus").addEventListener("change", updateDoctorStatus);
});

// Prompt for doctor name when page loads
function promptForDoctorName() {
    doctorName = prompt("Please enter your name (e.g., Dr. Smith):", "");
    if (!doctorName) {
        doctorName = "Unknown Doctor";
    }
    
    // Display doctor name after it's set
    document.getElementById("doctorNameDisplay").textContent = `Welcome, ${doctorName}`;
    
    // Now that we have the doctor name, fetch appointments
    fetchDoctorAppointments();
}

// Fetch appointments assigned to this doctor
async function fetchDoctorAppointments() {
    try {
        const response = await fetch(`/api/doctor/appointments?doctor=${encodeURIComponent(doctorName)}`);
        const data = await response.json();
        const appointmentList = document.getElementById("appointmentsList");
        appointmentList.innerHTML = "";
        
        if (data.appointments.length === 0) {
            appointmentList.innerHTML = "<p>No appointments assigned to you yet.</p>";
            return;
        }
        
        data.appointments.forEach(appointment => {
            const appointmentDiv = document.createElement("div");
            appointmentDiv.className = "appointment";
            if (appointment.emergency) {
                appointmentDiv.classList.add("emergency");
            }
            
            const emergency = appointment.emergency ? "⚠️ EMERGENCY" : "";
            appointmentDiv.innerHTML = `
                <h3>${appointment.name} (${appointment.age}) ${emergency}</h3>
                <p>Department: ${appointment.department}</p>
                <p>Appointment Time: ${new Date(appointment.appointmentTime).toLocaleString()}</p>
            `;
            
            const completeButton = document.createElement("button");
            completeButton.textContent = "Complete Appointment";
            completeButton.onclick = async function() {
                try {
                    const response = await fetch("/api/doctor/complete", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ 
                            requestId: appointment.id,
                            doctorName: doctorName
                        })
                    });
                    const result = await response.json();
                    alert(result.message);
                    fetchDoctorAppointments();
                } catch (error) {
                    console.error("Error completing appointment:", error);
                    alert("Failed to complete appointment");
                }
            };
            
            appointmentDiv.appendChild(completeButton);
            appointmentList.appendChild(appointmentDiv);
        });
    } catch (error) {
        console.error("Error fetching doctor appointments:", error);
        document.getElementById("appointmentsList").innerHTML = 
            "<p>Error loading appointments. Please try again later.</p>";
    }
}

// Update doctor status
async function updateDoctorStatus() {
    const status = document.getElementById("doctorStatus").value;
    document.getElementById("currentStatus").textContent = 
        status.charAt(0).toUpperCase() + status.slice(1); // Capitalize status
    
    try {
        await fetch("/api/doctor/status", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ 
                doctor: doctorName,
                status: status 
            })
        });
    } catch (error) {
        console.error("Error updating status:", error);
        alert("Failed to update status");
    }
}

// Refresh appointments every 30 seconds
setInterval(fetchDoctorAppointments, 30000);