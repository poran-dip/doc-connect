// Client-side JavaScript (patient.js)
document.getElementById("patientForm").addEventListener("submit", async function(event) {
    event.preventDefault();
    
    const name = document.getElementById("name").value;
    const age = document.getElementById("age").value;
    const department = document.getElementById("department").value;
    const appointmentTime = document.getElementById("appointmentTime").value;
    const emergency = document.getElementById("emergency").checked;
    
    const requestData = { name, age, department, appointmentTime, emergency };
    
    try {
        const response = await fetch("/api/patient/request", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(requestData)
        });
        const result = await response.json();
        alert(result.message);
    } catch (error) {
        console.error("Error submitting request:", error);
    }
});
