// Server-side JavaScript (server.js - Express API)
const express = require("express");
const app = express();
const path = require("path");
app.use(express.json());

let patientRequests = [];
let doctorStatus = [];
let completedAppointments = [];

let doctors = [
    { name: "Dr. Smith", specialization: "Cardiology", status: "available" },
    { name: "Dr. Johnson", specialization: "Neurology", status: "available" },
    { name: "Dr. Williams", specialization: "Orthopedics", status: "available" },
    { name: "Dr. Brown", specialization: "General Medicine", status: "available" }
  ];
  
// Serve static files (HTML, CSS, JS)
app.use(express.static("public"));

// Routes to serve specific HTML pages
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "public", "patient.html"));
});

app.get("/hospital", (req, res) => {
    res.sendFile(path.join(__dirname, "public", "hospital.html"));
});

app.get("/doctor", (req, res) => {
    res.sendFile(path.join(__dirname, "public", "doctor.html"));
});

app.post("/api/patient/request", (req, res) => {
    const { name, age, department, appointmentTime, emergency } = req.body;
    if (!name || !age || !department || !appointmentTime) {
        return res.status(400).json({ message: "All fields are required" });
    }
    
    const newRequest = { id: patientRequests.length + 1, name, age, department, appointmentTime, emergency };
    patientRequests.push(newRequest);
    console.log("New Patient Request:", newRequest);
    res.status(201).json({ message: "Appointment request submitted successfully", request: newRequest, requests: patientRequests });
});

app.get("/api/patient/requests", (req, res) => {
    res.json({ requests: patientRequests });
});

app.get("/api/hospital/doctors", (req, res) => {
    const availableDoctors = doctors.filter(doc => doc.status === "available");
    res.json({ doctors: availableDoctors });
});

app.post("/api/hospital/assign", (req, res) => {
    const { requestId, doctorName } = req.body;
    if (!requestId || !doctorName) {
        return res.status(400).json({ message: "Request ID and doctor name are required" });
    }

    const requestIndex = patientRequests.findIndex(req => req.id === requestId);
    if (requestIndex === -1) {
        return res.status(404).json({ message: "Request not found" });
    }

    const doctorIndex = doctors.findIndex(doc => doc.name === doctorName);
    if (doctorIndex === -1) {
        return res.status(404).json({ message: "Doctor not found" });
    }

    if (doctors[doctorIndex].status !== "available") {
        return res.status(400).json({ message: "Doctor is not available" });
    }

    // Assign doctor and mark as busy
    patientRequests[requestIndex].assignedDoctor = doctorName;
    doctors[doctorIndex].status = "busy";
    
    console.log("Doctor assigned:", doctorName, "to request ID:", requestId);
    res.json({ message: "Doctor assigned successfully", request: patientRequests[requestIndex] });
});

// Get appointments for a specific doctor
app.get("/api/doctor/appointments", (req, res) => {
    const doctor = req.query.doctor;
    if (!doctor) {
        return res.status(400).json({ message: "Doctor name is required" });
    }
    
    const appointments = patientRequests.filter(req => 
        req.assignedDoctor === doctor && !completedAppointments.includes(req.id)
    );
    
    res.json({ appointments });
});

// Update doctor status
app.post("/api/doctor/status", (req, res) => {
    const { doctor, status } = req.body;
    if (!doctor || !status) {
        return res.status(400).json({ message: "Doctor name and status are required" });
    }
    
    // Update or add doctor status
    const doctorIndex = doctorStatus.findIndex(d => d.doctor === doctor);
    if (doctorIndex !== -1) {
        doctorStatus[doctorIndex].status = status;
    } else {
        doctorStatus.push({ doctor, status });
    }
    
    console.log(`Doctor ${doctor} status updated to: ${status}`);
    res.json({ message: "Status updated successfully" });
});

// Complete an appointment
app.post("/api/doctor/complete", (req, res) => {
    const { requestId, doctorName } = req.body;
    if (!requestId || !doctorName) {
        return res.status(400).json({ message: "Request ID and doctor name are required" });
    }

    const requestIndex = patientRequests.findIndex(req => req.id === requestId);
    if (requestIndex === -1) {
        return res.status(404).json({ message: "Appointment not found" });
    }

    if (patientRequests[requestIndex].assignedDoctor !== doctorName) {
        return res.status(403).json({ message: "This appointment is not assigned to you" });
    }

    completedAppointments.push(requestId);
    patientRequests[requestIndex].completed = true;
    patientRequests[requestIndex].completedBy = doctorName;
    patientRequests[requestIndex].completedAt = new Date().toISOString();

    // Free up the doctor
    const doctorIndex = doctors.findIndex(doc => doc.name === doctorName);
    if (doctorIndex !== -1) {
        doctors[doctorIndex].status = "available";
    }

    console.log("Appointment completed:", requestId, "by doctor:", doctorName);
    res.json({ message: "Appointment completed successfully" });
});

app.listen(3000, () => console.log("Server running on port 3000"));
