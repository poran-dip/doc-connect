"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.JWT_DOCTOR_SECRET = exports.JWT_HOSPITAL_SECRET = exports.JWT_PATIENT_SECRET = void 0;
exports.JWT_PATIENT_SECRET = "patientkitopi";
exports.JWT_HOSPITAL_SECRET = "hospitalkitopi";
exports.JWT_DOCTOR_SECRET = "doctorkitopi";
