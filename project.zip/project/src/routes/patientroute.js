"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.patientroute = void 0;
const express_1 = require("express");
const db_1 = require("../database/db");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const config_1 = require("../config");
exports.patientroute = (0, express_1.Router)();
// Authentication routes
exports.patientroute.post("/signup", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { name, age, password, email } = req.body;
    try {
        yield db_1.Patientmodel.create({
            email,
            age,
            password,
            name
        });
        res.json({
            message: "you are signed up"
        });
    }
    catch (e) {
        res.status(500).send({ error: "An error occurred" });
    }
}));
exports.patientroute.post("/signin", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { email, password } = req.body;
    const finduser = yield db_1.Patientmodel.findOne({
        email: email,
        password: password
    });
    if (finduser) {
        const token = jsonwebtoken_1.default.sign({
            id: finduser._id
        }, config_1.JWT_PATIENT_SECRET);
        res.json({
            token,
            user: {
                id: finduser._id,
                name: finduser.name,
                email: finduser.email,
                age: finduser.age
            }
        });
    }
    else {
        res.status(403).json({
            message: "Invalid Credentials"
        });
    }
}));
// Middleware to verify patient token
const verifyPatientToken = (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
        return res.status(401).json({ message: "Authorization header missing" });
    }
    const token = authHeader.split(' ')[1];
    try {
        const decoded = jsonwebtoken_1.default.verify(token, config_1.JWT_PATIENT_SECRET);
        req.body.patientId = decoded.id;
        next();
    }
    catch (error) {
        return res.status(401).json({ message: "Invalid token" });
    }
};
// Appointment request route
exports.patientroute.post("/request-appointment", verifyPatientToken, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { name, age, department, appointmentTime, emergency, patientId } = req.body;
    if (!name || !age || !department || !appointmentTime) {
        return res.status(400).json({ message: "All fields are required" });
    }
    try {
        const newRequest = yield db_1.AppointmentRequestModel.create({
            name,
            age,
            department,
            appointmentTime: new Date(appointmentTime),
            emergency: emergency || false,
            patientId
        });
        res.status(201).json({
            message: "Appointment request submitted successfully",
            request: newRequest
        });
    }
    catch (error) {
        console.error("Error creating appointment request:", error);
        res.status(500).json({ message: "Error creating appointment request" });
    }
}));
// Get patient's appointment requests
exports.patientroute.get("/my-appointments", verifyPatientToken, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { patientId } = req.body;
    try {
        const appointments = yield db_1.AppointmentRequestModel.find({ patientId })
            .populate('assignedDoctor', 'name specialization')
            .sort({ appointmentTime: 1 });
        res.json({ appointments });
    }
    catch (error) {
        console.error("Error fetching appointments:", error);
        res.status(500).json({ message: "Error fetching appointments" });
    }
}));
exports.default = exports.patientroute;
