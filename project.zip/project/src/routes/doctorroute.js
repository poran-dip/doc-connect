"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.doctorRoute = void 0;
const express_1 = require("express");
const db_1 = require("../database/db");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const config_1 = require("../config");
exports.doctorRoute = (0, express_1.Router)();
// Authentication for doctors
exports.doctorRoute.post("/signin", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { email, password } = req.body;
    const doctor = yield db_1.Doctormodel.findOne({
        email: email,
        password: password
    });
    if (doctor) {
        const token = jsonwebtoken_1.default.sign({
            id: doctor._id
        }, config_1.JWT_DOCTOR_SECRET);
        res.json({
            token,
            doctor: {
                id: doctor._id,
                name: doctor.name,
                email: doctor.email,
                specialization: doctor.specialization,
                status: doctor.status
            }
        });
    }
    else {
        res.status(403).json({
            message: "Invalid Credentials"
        });
    }
}));
// Middleware to verify doctor token
const verifyDoctorToken = (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
        return res.status(401).json({ message: "Authorization header missing" });
    }
    const token = authHeader.split(' ')[1];
    try {
        const decoded = jsonwebtoken_1.default.verify(token, config_1.JWT_DOCTOR_SECRET);
        req.body.doctorId = decoded.id;
        next();
    }
    catch (error) {
        return res.status(401).json({ message: "Invalid token" });
    }
};
// Get doctor's assigned appointments
exports.doctorRoute.get("/my-appointments", verifyDoctorToken, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { doctorId } = req.body;
    try {
        const appointments = yield db_1.AppointmentRequestModel.find({
            assignedDoctor: doctorId,
            status: "assigned"
        }).sort({ emergency: -1, appointmentTime: 1 });
        res.json({ appointments });
    }
    catch (error) {
        console.error("Error fetching appointments:", error);
        res.status(500).json({ message: "Error fetching appointments" });
    }
}));
// Update doctor status
exports.doctorRoute.post("/update-status", verifyDoctorToken, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { doctorId, status } = req.body;
    if (!status || !["available", "busy"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
    }
    try {
        const doctor = yield db_1.Doctormodel.findById(doctorId);
        if (!doctor) {
            return res.status(404).json({ message: "Doctor not found" });
        }
        doctor.status = status;
        yield doctor.save();
        res.json({ message: "Status updated successfully", status });
    }
    catch (error) {
        console.error("Error updating status:", error);
        res.status(500).json({ message: "Error updating status" });
    }
}));
// Complete an appointment
exports.doctorRoute.post("/complete-appointment", verifyDoctorToken, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { appointmentId, doctorId } = req.body;
    if (!appointmentId) {
        return res.status(400).json({ message: "Appointment ID is required" });
    }
    try {
        const appointment = yield db_1.AppointmentRequestModel.findById(appointmentId);
        if (!appointment) {
            return res.status(404).json({ message: "Appointment not found" });
        }
        if (appointment.assignedDoctor.toString() !== doctorId) {
            return res.status(403).json({ message: "This appointment is not assigned to you" });
        }
        // Update the appointment
        appointment.status = "completed";
        appointment.completedBy = doctorId;
        appointment.completedAt = new Date();
        yield appointment.save();
        // Update doctor status
        const doctor = yield db_1.Doctormodel.findById(doctorId);
        if (doctor) {
            doctor.status = "available";
            yield doctor.save();
        }
        res.json({ message: "Appointment completed successfully" });
    }
    catch (error) {
        console.error("Error completing appointment:", error);
        res.status(500).json({ message: "Error completing appointment" });
    }
}));
exports.default = exports.doctorRoute;
