"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.hospitalRoute = void 0;
const express_1 = require("express");
const db_1 = require("../database/db");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const config_1 = require("../config");
exports.hospitalRoute = (0, express_1.Router)();
// Authentication for hospital admin
exports.hospitalRoute.post("/signin", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { email, password } = req.body;
    const hospital = yield db_1.Hospitalmodel.findOne({
        email: email,
        password: password
    });
    if (hospital) {
        const token = jsonwebtoken_1.default.sign({
            id: hospital._id
        }, config_1.JWT_HOSPITAL_SECRET);
        res.json({
            token,
            hospital: {
                id: hospital._id,
                name: hospital.name,
                email: hospital.email,
                location: hospital.location
            }
        });
    }
    else {
        res.status(403).json({
            message: "Invalid Credentials"
        });
    }
}));
// Middleware to verify hospital token
const verifyHospitalToken = (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
        return res.status(401).json({ message: "Authorization header missing" });
    }
    const token = authHeader.split(' ')[1];
    try {
        const decoded = jsonwebtoken_1.default.verify(token, config_1.JWT_HOSPITAL_SECRET);
        req.body.hospitalId = decoded.id;
        next();
    }
    catch (error) {
        return res.status(401).json({ message: "Invalid token" });
    }
};
// Get all appointment requests
exports.hospitalRoute.get("/appointment-requests", verifyHospitalToken, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const requests = yield db_1.AppointmentRequestModel.find()
            .sort({ emergency: -1, appointmentTime: 1 })
            .populate('assignedDoctor', 'name specialization');
        res.json({ requests });
    }
    catch (error) {
        console.error("Error fetching appointment requests:", error);
        res.status(500).json({ message: "Error fetching appointment requests" });
    }
}));
// Get available doctors
exports.hospitalRoute.get("/available-doctors", verifyHospitalToken, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const doctors = yield db_1.Doctormodel.find({ status: "available" });
        res.json({ doctors });
    }
    catch (error) {
        console.error("Error fetching available doctors:", error);
        res.status(500).json({ message: "Error fetching available doctors" });
    }
}));
// Assign doctor to appointment
exports.hospitalRoute.post("/assign-doctor", verifyHospitalToken, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { requestId, doctorId } = req.body;
    if (!requestId || !doctorId) {
        return res.status(400).json({ message: "Request ID and doctor ID are required" });
    }
    try {
        // Find the appointment request
        const request = yield db_1.AppointmentRequestModel.findById(requestId);
        if (!request) {
            return res.status(404).json({ message: "Appointment request not found" });
        }
        // Find the doctor
        const doctor = yield db_1.Doctormodel.findById(doctorId);
        if (!doctor) {
            return res.status(404).json({ message: "Doctor not found" });
        }
        if (doctor.status !== "available") {
            return res.status(400).json({ message: "Doctor is not available" });
        }
        // Update the request and doctor
        request.assignedDoctor = doctorId;
        request.status = "assigned";
        yield request.save();
        doctor.status = "busy";
        yield doctor.save();
        res.json({
            message: "Doctor assigned successfully",
            request: yield request.populate('assignedDoctor', 'name specialization')
        });
    }
    catch (error) {
        console.error("Error assigning doctor:", error);
        res.status(500).json({ message: "Error assigning doctor" });
    }
}));
exports.default = exports.hospitalRoute;
