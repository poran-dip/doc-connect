"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const patientroute_1 = require("./routes/patientroute");
const doctorroute_1 = require("./routes/doctorroute");
const hospitaltoute_1 = require("./routes/hospitaltoute");
const app = (0, express_1.default)();
app.use(express_1.default.json());
app.use("/api/v1/patient", patientroute_1.patientroute);
app.use("/api/v1/doctor", doctorroute_1.doctorrouter);
app.use("/api/v1/hospital", hospitaltoute_1.hospitalroutes);
app.listen(3000);
