import express from 'express'
import { patientroute } from './routes/patientroute';
import { doctorRoute } from './routes/doctorroute';
import { hospitalRoute } from './routes/hospitalroute';

const app=express();
app.use(express.json());

app.use("/api/v1/patient",patientroute);
app.use("/api/v1/doctor",doctorRoute);
app.use("/api/v1/hospital",hospitalRoute)
app.listen(3000);