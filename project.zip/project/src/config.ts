export const JWT_PATIENT_SECRET="patientkitopi";
export const JWT_HOSPITAL_SECRET="hospitalkitopi";
export const JWT_DOCTOR_SECRET="doctorkitopi";